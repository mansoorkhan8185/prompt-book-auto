// One-time clean-up: moves pictures stored inside the database (data:image...) into the GitHub repo
// and replaces them with short links. This makes the app load much faster.
//   node migrate.mjs files   -> saves the image files and a list of changes
//   node migrate.mjs apply   -> writes the new links into the database
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { getAdmin } from "./lib/generator.js";

const MODE = process.argv[2] || "files";
const DIR = "images/migrated";
const MANIFEST = "migrate-updates.json";
const repo = process.env.GITHUB_REPOSITORY;
const branch = process.env.GITHUB_REF_NAME || "main";

function walk(node, p, out) {
  if (typeof node === "string") {
    if (/^data:image\/(png|jpe?g|webp|gif);base64,/i.test(node) && node.length > 1500) out.push({ path: p, value: node });
  } else if (node && typeof node === "object") {
    for (const k of Object.keys(node)) walk(node[k], p ? p + "/" + k : k, out);
  }
}

const fb = getAdmin();
const db = fb.database();

if (MODE === "files") {
  const snap = await db.ref("/").once("value");
  const found = [];
  walk(snap.val(), "", found);
  console.log("Pictures stored inside the database:", found.length);
  fs.mkdirSync(DIR, { recursive: true });
  const sharp = (await import("sharp")).default;
  const updates = {};
  let before = 0, after = 0;
  for (const f of found) {
    const m = f.value.match(/^data:image\/([a-z0-9+]+);base64,(.*)$/is);
    let buf = Buffer.from(m[2], "base64");
    before += buf.length;
    const isIcon = /icon/i.test(f.path);
    const isBanner = /banner/i.test(f.path);
    const width = isIcon ? 192 : isBanner ? 640 : 720;
    let ext = "jpg";
    try {
      let img = sharp(buf).resize({ width, withoutEnlargement: true });
      if (isIcon && /png|webp/i.test(m[1])) { buf = await img.png({ compressionLevel: 9 }).toBuffer(); ext = "png"; }
      else buf = await img.jpeg({ quality: 78 }).toBuffer();
    } catch (e) { console.warn("Could not resize", f.path, e.message); ext = m[1].replace("jpeg", "jpg"); }
    after += buf.length;
    const name = crypto.createHash("sha1").update(f.value).digest("hex").slice(0, 12) + "." + ext;
    fs.writeFileSync(path.join(DIR, name), buf);
    updates[f.path] = `https://raw.githubusercontent.com/${repo}/${branch}/${DIR}/${name}`;
    console.log(f.path, "->", name, Math.round(buf.length / 1024) + " KB");
  }
  fs.writeFileSync(MANIFEST, JSON.stringify(updates, null, 1));
  console.log(`Total before: ${Math.round(before / 1024)} KB, after: ${Math.round(after / 1024)} KB`);
} else if (MODE === "apply") {
  const updates = JSON.parse(fs.readFileSync(MANIFEST, "utf8"));
  const keys = Object.keys(updates);
  if (!keys.length) { console.log("Nothing to change."); process.exit(0); }
  // make sure the new links work before touching the database
  for (const k of keys.slice(0, 3)) {
    const r = await fetch(updates[k]);
    if (!r.ok) throw new Error("New image link is not reachable yet (" + r.status + "): " + updates[k]);
  }
  await db.ref("/").update(updates);
  console.log("Updated", keys.length, "pictures in the database.");
}
process.exit(0);
