import { runGenerator } from "./lib/generator.js";

try {
  const r = await runGenerator();
  console.log("OK:", JSON.stringify(r));
  process.exit(0);
} catch (e) {
  console.error("FAILED:", e && e.message ? e.message : e);
  process.exit(1);
}
